#include <iostream>

using namespace std;

int main(int argc, char const *argv[])
{
    printf("hello");
    return 0;
}
