
#include <iostream>
#include <unistd.h>
#include "rm_interface.h"

using namespace std;

class Sanding_Demo
{
private:
    rm_robot_handle *arm_handle;
    rm_waypoint_t *pose[4];
public:
    int times;

    bool Run(int times);
    Sanding_Demo(rm_thread_mode_e mode);
    ~Sanding_Demo();
};

Sanding_Demo::Sanding_Demo(rm_thread_mode_e mode): times(0)
{
    // 输出api版本号
    char *version = rm_api_version();
    printf("api version: %s\n", version);

    // 初始化线程模式
    if (!rm_init(mode)) {
        printf("Thread mode initialization failed!");
        return;
    }

    // 连接机械臂
    arm_handle = rm_create_robot_arm("192.168.1.18", 8080);
    if(arm_handle->id == -1) {
        rm_delete_robot_arm(arm_handle);
        printf("Arm connect err...\n");
    }
    else if(arm_handle != NULL) {
        printf("Connect success,arm id %d\n",arm_handle->id);
    }

    /* 控制机械臂到局部路径点 */ 
    //得到局部点位
    if (rm_get_given_global_waypoint(arm_handle, "initial", pose[0]) || 
        rm_get_given_global_waypoint(arm_handle, "point_1", pose[1]) ||
        rm_get_given_global_waypoint(arm_handle, "point_2", pose[2]) ||
        rm_get_given_global_waypoint(arm_handle, "point_3", pose[3])) {
        return;
    }
    else if (rm_movej(arm_handle, pose[0]->joint, 100, 0, 0, true) || 
        rm_movej(arm_handle, pose[1]->joint, 50, 0, 0, true)) {
        printf("Movej actions execution failed!");
    }
    else {
        printf("Action initialization succeessful!");
    }
}

Sanding_Demo::~Sanding_Demo()
{
    // 删除机械臂实例
    rm_delete_robot_arm(arm_handle);
    // 撤销所有线程
    rm_destory();
}

bool Sanding_Demo::Run(int times)
{
    // 机械臂规划到路径点
    rm_movej(arm_handle, pose[0]->joint, 50, 0, 0, true);

    /* 开启力位混合控制模式 */ 
    // 参数配置
    rm_force_position_t param = {
        1,  // 传感器：一维力（0），六维力（1）
        1,  // 力坐标系：基坐标系（0），工具坐标系（1）
        {3, 3, 8, 3, 3, 3},  // 各轴力矩模式数组
        {0, 0, 20, 0, 0, 0},  // 各轴的期望力/力矩数组
        {0.1, 0.1, 0.1, 10, 10, 10}  // 各轴的最大线速度/最大角速度限制数组
    };
    // 开启模式
    if (rm_set_force_position_new(arm_handle, param)) {
        return false;
    }

    // 循环打磨
    int _times = 0;
    while (_times < times) {
        rm_movej(arm_handle, pose[1]->joint, 50, 0, 0, true);
        rm_movej(arm_handle, pose[2]->joint, 50, 0, 0, true);
        _times++;
    }
    
    // 关闭力位混合控制
    if (!rm_stop_force_position(arm_handle)) {
        rm_movej(arm_handle, pose[3]->joint, 50, 0, 0, true);
        this->times++;
        return true;
    } else {
        return false;
    }
}


int main() {
    // 初始化设备
    Sanding_Demo robot(RM_SINGLE_MODE_E);
    
    // 设置延迟
    sleep(2);

    // 循环控制打磨工件数
    while (robot.times < 100) {
        // 设置内部循环打磨同一工件次数
        if (!robot.Run(10)) {
            break;
        }
        
    }
    
    system("pause");
    return 0;
}