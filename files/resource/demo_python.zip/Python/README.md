# Robotic_Arm

第二代睿尔曼机械臂Python版本二次开发包  

## 安装  

你可以通过pip来安装这个包：  

```bash  
pip install Robotic_Arm
```