import sys
import os
import time
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from Robotic_Arm.rm_robot_interface import *


class Sanding_Demo:

    def __init__(self, mode: rm_thread_mode_e = None):
        # 实例化机械臂控制线程个数
        self._arm = RoboticArm(mode)

        # 连接机械臂, 打印连接id
        self._arm.rm_create_robot_arm("192.168.1.18", 8080)

        print("Algorithm library version:", self._arm.rm_algo_version())
        print("*******Algorithm version: v1.0.0*******")

        # 设置执行次数
        self.times = 0

        # 控制机械臂到局部路径点
        self._arm.rm_movej(self._arm.rm_get_given_global_waypoint("initial")[1]["joint"], 100, 0, 0, True)
        self._arm.rm_movej(self._arm.rm_get_given_global_waypoint("point_1")[1]["joint"], 50, 0, 0, True)
    
    def run(self, times: int=10):
        # 机械臂规划到路径点
        self._arm.rm_movej(self._arm.rm_get_given_global_waypoint("point_1")[1]["joint"], 50, 0, 0, True)
        
        # 配置力位混合控制形参
        param = rm_force_position_t(1, 1, (3, 3, 8, 3, 3, 3), (0, 0, 20, 0, 0, 0), (0.1, 0.1, 0.1, 10, 10, 10))
        
        # 开启力位混合控制
        if self._arm.rm_set_force_position_new(param):
            return False
        
        _times = 0
        # 循环打磨
        while _times < times:
            self._arm.rm_movej(self._arm.rm_get_given_global_waypoint("point_1")[1]["joint"], 50, 0, 0, True)
            self._arm.rm_movej(self._arm.rm_get_given_global_waypoint("point_2")[1]["joint"], 50, 0, 0, True)
            _times += 1

        # 关闭力位混合控制
        if not self._arm.rm_stop_force_position():
            self._arm.rm_movej(self._arm.rm_get_given_global_waypoint("point_3")[1]["joint"], 50, 0, 0, True)
            self.times += 1
            return True
        else:
            return False

if __name__=='__main__':
    # 初始化设备
    robot = Sanding_Demo(rm_thread_mode_e.RM_SINGLE_MODE_E)

    # 设置延时
    time.sleep(2)

    # 循环控制打磨工件数
    while robot.stime < 100:
        # 设置内部循环打磨同一工件次数
        if not robot.run(10):
            break